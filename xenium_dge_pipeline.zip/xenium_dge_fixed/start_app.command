#!/usr/bin/env bash
# start_app.command
# -----------------
# Double-click this file in Finder to launch the Xenium DGE web interface.
# macOS will open a Terminal window and start the local web server.
# Your browser opens automatically at http://localhost:8501

# Change to the directory containing this script
cd "$(dirname "$0")"

echo "======================================================"
echo "  Xenium DGE Pipeline — Local Web Interface"
echo "======================================================"
echo ""

# Locate conda
CONDA_PATH=""
for candidate in \
    "$HOME/miniforge3/bin/conda" \
    "/opt/homebrew/Caskroom/miniforge/base/bin/conda" \
    "$HOME/mambaforge/bin/conda" \
    "/usr/local/miniforge3/bin/conda"
do
    if [[ -f "$candidate" ]]; then
        CONDA_PATH="$candidate"
        break
    fi
done

if [[ -z "$CONDA_PATH" ]]; then
    echo "ERROR: conda not found. Run ./install_mac.sh first."
    read -p "Press Enter to close..."
    exit 1
fi

CONDA_BASE=$("$CONDA_PATH" info --base)
source "$CONDA_BASE/etc/profile.d/conda.sh"

# Activate environment
if ! conda activate xenium_dge 2>/dev/null; then
    echo "ERROR: 'xenium_dge' environment not found."
    echo "Run ./install_mac.sh to create it."
    read -p "Press Enter to close..."
    exit 1
fi

echo "Environment: xenium_dge"
echo "Python: $(python --version)"
echo ""

# Check streamlit
if ! python -c "import streamlit" 2>/dev/null; then
    echo "Installing streamlit and plotly..."
    pip install streamlit plotly --quiet
fi

# Open browser after a short delay
(sleep 2.5 && open "http://localhost:8501") &

echo "Starting web interface..."
echo "Open: http://localhost:8501"
echo "Press Ctrl+C to stop."
echo ""

# Launch streamlit from the app directory
cd app
streamlit run app.py \
    --server.port 8501 \
    --server.headless false \
    --browser.gatherUsageStats false \
    --server.enableCORS false

echo ""
echo "Server stopped."
read -p "Press Enter to close..."
